import css from './window.module.css'
import {useState} from 'react'

export default function BasketPizzas (props){
    return(
        <div className={css.block}>
            <img className={css.img} src={props.img}/>
            <div className={css.nameDes} >
                <div className={css.name}>{props.name}</div>
            <div className={css.des}>Средняя , традиционая тесто</div>
            </div>
            
            <div className={css.cost}>{props.cost} сом</div>
        </div>
    )
}
export const Window = (props)=>{
    const removeCart = ()=>{
        props.setCart(' ')
    }
    
    
    
    
    
    return(
        <div className={css.windowCart + props.cart}>
            <div className={css.closeBtn} onClick={removeCart}>
            <svg width="25" height="25" viewBox="0 0 25 25" fill="none"><path fillRule="evenodd" clipRule="evenodd" d="M9.61 12.199L.54 3.129A1.833 1.833 0 113.13.536l9.07 9.07L21.27.54a1.833 1.833 0 012.592 2.592l-9.068 9.068 9.07 9.07a1.833 1.833 0 01-2.59 2.592l-9.072-9.07-9.073 9.073a1.833 1.833 0 01-2.591-2.592L9.61 12.2z" fill="#fff"></path></svg>
            </div>
            <div className={css.basketWindow}>
                <div>
                    {props.basket.length} товаров на {
                       
                    } сом
                </div>
                  {props.pizza.map((e) =>{ 
                        
                        
                       
                    }
                  )}
            </div>
        </div>
    )
}