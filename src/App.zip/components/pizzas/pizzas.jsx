import { Link } from 'react-router-dom'
import css from './pizzas.module.css'

export const Pizzas = (props) => {

    const onSelect = () =>{
      const basket = JSON.parse(localStorage.getItem('basket')) || []
      if(!basket.includes(props.id)){
      basket.push(props.id)
      localStorage.setItem('basket', JSON.stringify(basket))
      props.setBasket(basket)
      }
    }
    return(
        <div>

            
                <Link to='/' className={css.pizza2}>
                    
                        <div className={css.imgWrapper}>
                           <img src={props.img}/>
                        </div>
                        <div>
                              <div className={css.pizzaName}>{props.name}</div> <br />
                      
                       <div className={css.description}>{props.des}</div> 
                        </div>
                    
                    <div className={css.footer}>
                      <div>от {props.cost} сом</div>
                      <div onClick={onSelect} className={css.choose}>Выбрать</div>
                    </div>
                </Link>
            </div>
    )
}