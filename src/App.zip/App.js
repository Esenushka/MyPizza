
import './App.css';
import {Header} from './components/header/header'
import React from "react";

import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import { Navbar } from './components/navbar/navbar';
import Main from './pages/main/Main';
import {useState} from 'react'
import {Window} from './components/basketWindow/window'


function App() {
  const [basket, setBasket] = useState(JSON.parse(localStorage.getItem('basket')) || [])
  const [pizza, setPizza] = useState([]);
  const [cart, setCart] = useState([])
  return (
    <Router>
    <div className='App'>
      <Window pizza={pizza} basket={basket} setCart={setCart} cart={cart}/>
      <Header/>
      <Navbar setCart={setCart}  basket={basket}/>
      <Switch>
         <Route exact path='/'>
          <Main pizza={pizza} setPizza={setPizza} setBasket={setBasket}/>
         </Route>
         <Route exact path='/stocks'>
            <div>STocKs</div>
         </Route>
      </Switch>

    </div>
  </Router>
);
}




export default App;
