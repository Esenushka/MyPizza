import css from './window.module.css'

export const Window = ()=>{
    return(
            <div className={css.basketWindow}>

            </div>
    )
}