import { Link } from 'react-router-dom'
import css from './navbar.module.css'
export const Navbar = (props) =>{
    const BasketWindow = ()=>{
        
    }
    return(
        <nav className={css.navbar}>
        <div className={'container ' + css.cont}>
             <div className={css.help}>
                 <Link className={css.navbars}>Пицца</Link>
                 <Link className={css.navbars}>Комбо</Link>
                 <Link className={css.navbars}>Закуски</Link>
                 <Link className={css.navbars}>Десерты</Link>
                 <Link className={css.navbars}>Напитки</Link>
                 <Link className={css.navbars}>Другие товары</Link>
                 <Link to='/stocks' className={css.navbars}>Акции</Link>
                 <Link className={css.navbars}>Контакты</Link>
                 <Link className={css.navbars}>О нас</Link>
                 <Link className={css.navbars}>Прямой эфир</Link>

             </div> 
             <div onClick={BasketWindow} className={css.bucket}>Корзина<div className={css.many}>{props.basket.length}</div></div>
        </div>
        
        </nav>
    )
}